
addpath(pwd); 
cd mex;
makeSolverMex;
addpath(pwd);
cd ..;
savepath;

